- Thanks for using Scooby
- Any issues just put them in the discord server #bugs

Site: https://gtayes.github.io/Scooby/

Discord: https://discord.io/ScoobyMenu

